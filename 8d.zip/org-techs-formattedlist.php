<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Formatter Tool - Format to 'subject',</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #000;
            background-color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 0;
            border: 2px solid #000;
            box-shadow: 8px 8px 0 #000;
        }
        
        header {
            background-color: #fff;
            color: #000;
            padding: 30px;
            text-align: center;
            border-bottom: 2px solid #000;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: -0.5px;
        }
        
        .subtitle {
            font-size: 1.1rem;
            color: #333;
            font-weight: 400;
        }
        
        .content {
            padding: 30px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
        }
        
        @media (max-width: 768px) {
            .content {
                grid-template-columns: 1fr;
                gap: 30px;
            }
        }
        
        .input-section, .output-section {
            display: flex;
            flex-direction: column;
        }
        
        h2 {
            color: #000;
            margin-bottom: 20px;
            font-size: 1.4rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding-bottom: 10px;
            border-bottom: 2px solid #000;
        }
        
        textarea {
            width: 100%;
            height: 300px;
            padding: 20px;
            border: 2px solid #000;
            border-radius: 0;
            font-family: 'Menlo', 'Monaco', 'Consolas', monospace;
            font-size: 14px;
            line-height: 1.8;
            resize: vertical;
            background-color: #fff;
            color: #000;
        }
        
        textarea:focus {
            outline: none;
            background-color: #fafafa;
        }
        
        .input-section textarea {
            border-color: #000;
        }
        
        .output-section textarea {
            border-color: #000;
            background-color: #f8f8f8;
        }
        
        .controls {
            margin-top: 25px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        button {
            padding: 12px 24px;
            border: 2px solid #000;
            border-radius: 0;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #fff;
            color: #000;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 0.5px;
        }
        
        button:hover {
            transform: translate(-2px, -2px);
            box-shadow: 4px 4px 0 #000;
        }
        
        button:active {
            transform: translate(0, 0);
            box-shadow: none;
        }
        
        .btn-primary {
            background-color: #000;
            color: #fff;
        }
        
        .btn-secondary {
            background-color: #fff;
            color: #000;
        }
        
        .btn-copy {
            background-color: #fff;
            color: #000;
        }
        
        .btn-copy:hover {
            background-color: #f0f0f0;
        }
        
        .btn-clear {
            background-color: #fff;
            color: #000;
        }
        
        .btn-clear:hover {
            background-color: #f0f0f0;
        }
        
        .info-box {
            background-color: #fff;
            border: 2px solid #000;
            padding: 20px;
            margin-top: 30px;
        }
        
        .info-box h3 {
            color: #000;
            margin-bottom: 15px;
            font-size: 1.2rem;
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .info-box ul {
            margin-left: 20px;
        }
        
        .info-box li {
            margin-bottom: 10px;
            color: #333;
        }
        
        .examples {
            margin-top: 30px;
            background-color: #fff;
            padding: 20px;
            border: 2px solid #000;
        }
        
        .examples h3 {
            color: #000;
            margin-bottom: 15px;
            font-size: 1.2rem;
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .examples p {
            font-size: 0.95rem;
            color: #333;
            margin-bottom: 12px;
            line-height: 1.6;
        }
        
        .examples strong {
            color: #000;
            font-weight: 700;
        }
        
        footer {
            text-align: center;
            padding: 25px;
            color: #000;
            font-size: 0.9rem;
            border-top: 2px solid #000;
            background-color: #fff;
            font-weight: 500;
        }
        
        .notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 20px 30px;
            background-color: #fff;
            color: #000;
            border: 2px solid #000;
            border-radius: 0;
            box-shadow: 4px 4px 0 #000;
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s;
            z-index: 1000;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .notification.show {
            transform: translateY(0);
            opacity: 1;
        }
        
        .separator {
            height: 2px;
            background-color: #000;
            margin: 30px 0;
        }
        
        .char-count {
            font-size: 0.9rem;
            color: #666;
            margin-top: 10px;
            text-align: right;
            font-family: monospace;
        }
        
        .input-header, .output-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>List Formatter</h1>
            <p class="subtitle">Convert lists to: 'item', format</p>
        </header>
        
        <div class="content">
            <div class="input-section">
                <div class="input-header">
                    <h2><i class="fas fa-arrow-right"></i> Input</h2>
                </div>
                <form method="POST" action="">
                    <textarea id="inputText" name="inputText" placeholder="Paste your list here (one per line or separated by commas)...

Example:
Mathematics
Physics
Chemistry
Biology

Or:
Apples, Oranges, Bananas

Supports: line breaks, commas, semicolons, pipes"><?php 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputText'])) {
    echo htmlspecialchars($_POST['inputText']);
} else {
    echo "Mathematics\nPhysics\nChemistry\nBiology\nHistory\nGeography\nEnglish\nComputer Science";
}
?></textarea>
                    <div class="char-count" id="inputCount">Characters: 0</div>
                    
                    <div class="controls">
                        <button type="submit" name="format" class="btn-primary">
                            <i class="fas fa-code"></i> Format List
                        </button>
                        <button type="button" id="clearInput" class="btn-clear">
                            <i class="fas fa-times"></i> Clear
                        </button>
                        <button type="button" id="loadExample" class="btn-secondary">
                            <i class="fas fa-file-alt"></i> Example
                        </button>
                    </div>
                </form>
                
                <div class="separator"></div>
                
                <div class="info-box">
                    <h3><i class="fas fa-info-circle"></i> Instructions</h3>
                    <ul>
                        <li>Paste or type your list in the input box</li>
                        <li>Click <strong>Format List</strong> to process</li>
                        <li>Copy formatted output from right panel</li>
                        <li>Accepts: line breaks, commas, semicolons, pipes</li>
                        <li>Removes empty lines automatically</li>
                    </ul>
                </div>
            </div>
            
            <div class="output-section">
                <div class="output-header">
                    <h2><i class="fas fa-arrow-left"></i> Output</h2>
                </div>
                <textarea id="outputText" readonly placeholder="Formatted output will appear here...
Format: 'item',
Example:
'Mathematics',
'Physics',
'Chemistry',"><?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inputText'])) {
    $input = $_POST['inputText'];
    
    // Clean and process the input
    $items = preg_split('/[\n,;|]+/', $input);
    
    $formattedItems = [];
    foreach ($items as $item) {
        $item = trim($item);
        if (!empty($item)) {
            // Escape single quotes in the item
            $item = str_replace("'", "\\'", $item);
            $formattedItems[] = "'" . htmlspecialchars($item) . "'";
        }
    }
    
    echo implode(",\n", $formattedItems);
}
?></textarea>
                <div class="char-count" id="outputCount">Characters: 0</div>
                
                <div class="controls">
                    <button type="button" id="copyOutput" class="btn-copy">
                        <i class="fas fa-copy"></i> Copy Output
                    </button>
                    <button type="button" id="selectAll" class="btn-secondary">
                        <i class="fas fa-mouse-pointer"></i> Select All
                    </button>
                    <button type="button" id="downloadText" class="btn-secondary">
                        <i class="fas fa-download"></i> Download
                    </button>
                </div>
                
                <div class="separator"></div>
                
                <div class="examples">
                    <h3><i class="fas fa-eye"></i> Format Examples</h3>
                    <p><strong>Input:</strong> Math, Science, History</p>
                    <p><strong>Output:</strong><br>'Math',<br>'Science',<br>'History',</p>
                    <div style="margin: 15px 0; height: 1px; background: #ddd;"></div>
                    <p><strong>Input:</strong> Item 1; Item 2; Item 3</p>
                    <p><strong>Output:</strong><br>'Item 1',<br>'Item 2',<br>'Item 3',</p>
                </div>
            </div>
        </div>
        
        <footer>
            <p>List Formatter Tool | Format: 'item', | <?php echo date('Y'); ?></p>
        </footer>
    </div>
    
    <div id="notification" class="notification">Output Copied</div>
    
    <script>
        // Copy to clipboard functionality
        document.getElementById('copyOutput').addEventListener('click', function() {
            const outputText = document.getElementById('outputText');
            outputText.select();
            outputText.setSelectionRange(0, 99999);
            
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    showNotification('Output Copied to Clipboard');
                } else {
                    showNotification('Failed to Copy - Select & Copy Manually');
                }
            } catch (err) {
                console.error('Copy failed:', err);
                showNotification('Failed to Copy - Select & Copy Manually');
            }
        });
        
        // Select all text in output
        document.getElementById('selectAll').addEventListener('click', function() {
            const outputText = document.getElementById('outputText');
            outputText.select();
            outputText.setSelectionRange(0, 99999);
        });
        
        // Download output as text file
        document.getElementById('downloadText').addEventListener('click', function() {
            const outputText = document.getElementById('outputText').value;
            if (!outputText.trim()) {
                showNotification('No Output to Download');
                return;
            }
            
            const blob = new Blob([outputText], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'formatted_list_' + new Date().toISOString().slice(0,10) + '.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showNotification('File Downloaded');
        });
        
        // Clear input
        document.getElementById('clearInput').addEventListener('click', function() {
            document.getElementById('inputText').value = '';
            document.getElementById('inputText').focus();
            updateCharCount();
        });
        
        // Load example
        document.getElementById('loadExample').addEventListener('click', function() {
            const examples = [
                "Mathematics\nPhysics\nChemistry\nBiology\nHistory\nGeography\nEnglish\nComputer Science",
                "Apples, Oranges, Bananas, Grapes, Strawberries",
                "Red; Blue; Green; Yellow; Purple",
                "Item 1|Item 2|Item 3|Item 4|Item 5",
                "Monday\nTuesday\nWednesday\nThursday\nFriday\nSaturday\nSunday",
                "John Doe's Book\nJane's Report\nO'Connor's Notes"
            ];
            
            const randomExample = examples[Math.floor(Math.random() * examples.length)];
            document.getElementById('inputText').value = randomExample;
            updateCharCount();
        });
        
        // Character counter
        function updateCharCount() {
            const inputText = document.getElementById('inputText').value;
            const outputText = document.getElementById('outputText').value;
            
            document.getElementById('inputCount').textContent = 
                `Characters: ${inputText.length} | Lines: ${inputText.split('\n').length}`;
            document.getElementById('outputCount').textContent = 
                `Characters: ${outputText.length} | Lines: ${outputText.split('\n').length}`;
        }
        
        // Show notification
        function showNotification(message) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
        
        // Auto-resize textareas
        const textareas = document.querySelectorAll('textarea');
        textareas.forEach(textarea => {
            textarea.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
                updateCharCount();
            });
            
            // Initial height
            setTimeout(() => {
                textarea.style.height = 'auto';
                textarea.style.height = (textarea.scrollHeight) + 'px';
            }, 100);
        });
        
        // Update character count on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateCharCount();
            document.getElementById('inputText').focus();
        });
        
        // Update character count on input
        document.getElementById('inputText').addEventListener('input', updateCharCount);
        
        // Auto-focus and select output text when it changes
        const outputText = document.getElementById('outputText');
        const observer = new MutationObserver(function() {
            updateCharCount();
        });
        
        observer.observe(outputText, { childList: true, characterData: true, subtree: true });
    </script>
</body>
</html>