<?php
// Direct dump - just the measures, one per line with deduplication
//Only display results with more than 8 occurrences

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db = 'foodbank';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Force plain text output
header('Content-Type: text/plain');

$sql = "SELECT organizational_measures FROM gdpr_register ORDER BY id";
$result = $conn->query($sql);

$all_measures = []; // Array to collect all measures for deduplication
$raw_measures = []; // Keep original order if needed

while($row = $result->fetch_assoc()) {
    $measures = $row['organizational_measures'];
    
    // Clean and split into array
    $clean = preg_replace('/\s*[.,;]\s*/', "\n", $measures);
    $clean = preg_replace('/\n+/', "\n", $clean); // Remove multiple newlines
    $clean = trim($clean);
    
    if (!empty($clean)) {
        // Split by newlines to get individual measures
        $measure_lines = explode("\n", $clean);
        
        foreach ($measure_lines as $measure) {
            $trimmed_measure = trim($measure);
            if (!empty($trimmed_measure)) {
                $raw_measures[] = $trimmed_measure;
            }
        }
    }
}

$conn->close();

echo "=== FILTERED RESULTS: Similar measures (fuzzy match) appearing more than 8 times ===\n\n";

// Fuzzy deduplication with frequency counting
$similarity_threshold = 80; // Percentage (0-100)
$fuzzy_groups = [];
$fuzzy_counts = [];

foreach ($raw_measures as $measure) {
    $found_similar = false;
    $measure_lower = strtolower($measure);
    
    foreach ($fuzzy_groups as $index => $group_measure) {
        $group_lower = strtolower($group_measure);
        
        // Calculate similarity
        similar_text($measure_lower, $group_lower, $similarity);
        
        if ($similarity >= $similarity_threshold) {
            // Add to existing group
            $fuzzy_counts[$index]++;
            $found_similar = true;
            break;
        }
    }
    
    if (!$found_similar) {
        // Create new group
        $fuzzy_groups[] = $measure;
        $fuzzy_counts[count($fuzzy_groups) - 1] = 1;
    }
}

// Filter groups that appear more than 8 times
$filtered_measures = [];
for ($i = 0; $i < count($fuzzy_groups); $i++) {
    if ($fuzzy_counts[$i] > 8) {
        $filtered_measures[] = [
            'text' => $fuzzy_groups[$i],
            'count' => $fuzzy_counts[$i]
        ];
    }
}

// Sort by count (descending) then alphabetically
usort($filtered_measures, function($a, $b) {
    // First sort by count (descending)
    if ($b['count'] != $a['count']) {
        return $b['count'] - $a['count'];
    }
    // Then sort alphabetically
    return strnatcasecmp($a['text'], $b['text']);
});

// Output filtered measures
if (empty($filtered_measures)) {
    echo "No similar measure groups appear more than 8 times in the data.\n";
} else {
    foreach ($filtered_measures as $item) {
        echo $item['text'] . "\n";
    }
}

echo "\n=== STATISTICS ===\n";
echo "Total measures extracted: " . count($raw_measures) . "\n";
echo "Unique fuzzy groups ({$similarity_threshold}% similarity): " . count($fuzzy_groups) . "\n";
echo "Groups appearing > 8 times: " . count($filtered_measures) . "\n";

// Calculate percentage
if (count($fuzzy_groups) > 0) {
    $percentage = round((count($filtered_measures) / count($fuzzy_groups)) * 100, 1);
    echo "Percentage of fuzzy groups: {$percentage}%\n";
}

// Show counts for each group (optional)
echo "\n=== FREQUENCY COUNTS ===\n";
foreach ($filtered_measures as $item) {
    echo "[" . str_pad($item['count'], 3) . "x] " . $item['text'] . "\n";
}