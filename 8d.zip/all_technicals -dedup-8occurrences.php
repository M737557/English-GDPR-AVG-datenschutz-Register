<?php
// Direct dump - just the measures, one per line with deduplication
// Only display results with more than 8 occurrences

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db = 'foodbank';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Force plain text output
header('Content-Type: text/plain');

$sql = "SELECT technical_measures FROM gdpr_register ORDER BY id";
$result = $conn->query($sql);

$raw_measures = []; // Keep all raw measures to count occurrences
$measure_counts = []; // Count occurrences of each measure

while($row = $result->fetch_assoc()) {
    $measures = $row['technical_measures'];
    
    // Clean and split into array
    $clean = preg_replace('/\s*[.,;]\s*/', "\n", $measures);
    $clean = preg_replace('/\n+/', "\n", $clean); // Remove multiple newlines
    $clean = trim($clean);
    
    if (!empty($clean)) {
        // Split by newlines to get individual measures
        $measure_lines = explode("\n", $clean);
        
        foreach ($measure_lines as $measure) {
            $trimmed_measure = trim($measure);
            if (!empty($trimmed_measure)) {
                $raw_measures[] = $trimmed_measure;
                
                // Count occurrences (exact matches for counting)
                if (!isset($measure_counts[$trimmed_measure])) {
                    $measure_counts[$trimmed_measure] = 0;
                }
                $measure_counts[$trimmed_measure]++;
            }
        }
    }
}

$conn->close();

// OPTION 3: Fuzzy deduplication with filtering for > 8 occurrences
$similarity_threshold = 80; // Percentage (0-100)
$fuzzy_unique = [];

foreach ($raw_measures as $measure) {
    // Skip if this exact measure has 8 or fewer occurrences
    if ($measure_counts[$measure] <= 8) {
        continue;
    }
    
    $is_similar = false;
    $measure_lower = strtolower($measure);
    
    foreach ($fuzzy_unique as $unique_measure) {
        $unique_lower = strtolower($unique_measure);
        
        // Calculate similarity
        similar_text($measure_lower, $unique_lower, $similarity);
        
        if ($similarity >= $similarity_threshold) {
            $is_similar = true;
            break;
        }
    }
    
    if (!$is_similar) {
        $fuzzy_unique[] = $measure;
    }
}

// SORT RESULTS ALPHABETICALLY (A-Z)
sort($fuzzy_unique);

// Output just the measures, one per line
foreach ($fuzzy_unique as $measure) {
    echo $measure . "\n";
}

echo "\n=== STATISTICS ===\n";
echo "Total measures found: " . count($raw_measures) . "\n";

// Count how many exact measures have > 8 occurrences
$exact_more_than_5 = 0;
foreach ($measure_counts as $count) {
    if ($count > 8) {
        $exact_more_than_5++;
    }
}
echo "Measures with >5 occurrences (exact): " . $exact_more_than_5 . "\n";
echo "Unique (fuzzy {$similarity_threshold}%) with >8 occurrences: " . count($fuzzy_unique) . "\n";